# Change Log
All notable changes to the "ariake" extension will be documented in this file.

## [0.0.4] - 2017-10-12
.vscodeignore fix
