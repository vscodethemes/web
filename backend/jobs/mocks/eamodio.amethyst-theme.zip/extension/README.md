[![](https://vsmarketplacebadge.apphb.com/version/eamodio.amethyst-theme.svg)](https://marketplace.visualstudio.com/items?itemName=eamodio.amethyst-theme) [![](https://vsmarketplacebadge.apphb.com/installs/eamodio.amethyst-theme.svg)](https://marketplace.visualstudio.com/items?itemName=eamodio.amethyst-theme) [![](https://vsmarketplacebadge.apphb.com/rating/eamodio.amethyst-theme.svg)](https://marketplace.visualstudio.com/items?itemName=eamodio.amethyst-theme)
# Amethyst Themes

A set of very purple dark themes, based on the built-in Dark+ theme

## Amethyst

![Amethyst preview](https://raw.githubusercontent.com/eamodio/vscode-amethyst-theme/master/images/preview.png)

## Dark Amethyst

![Dark Amethyst preview](https://raw.githubusercontent.com/eamodio/vscode-amethyst-theme/master/images/preview-dark.png)

## Dark Amethyst (Higher Contrast)

![Dark Amethyst (Higher Contrast) preview](https://raw.githubusercontent.com/eamodio/vscode-amethyst-theme/master/images/preview-dark-contrast.png)

## Known Issues

If you find any issues or inconsistencies, please open an issue on [GitHub](https://github.com/eamodio/vscode-amethyst-theme/issues)

- None